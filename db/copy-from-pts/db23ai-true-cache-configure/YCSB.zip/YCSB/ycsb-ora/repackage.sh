#!/bin/bash

mvn clean package
mvn install dependency:copy-dependencies
