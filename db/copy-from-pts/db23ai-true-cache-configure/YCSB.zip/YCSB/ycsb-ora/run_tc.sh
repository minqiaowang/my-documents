#!/bin/bash

source bin/env_true_cache


for i in 1 2 4 8 16 32 64
do
   bin/ycsb run truecache -cp $CLASSPATH -P ./workloads/workloadb  -P /home/opc/YCSB/ycsb-ora/truecache/db.properties  -jvm-args "-Xmx13g -Xms13g -Dsun.net.inetaddr.ttl=0" -p maxexecutiontime=300 -threads $i 1> /home/opc/YCSB/ycsb-ora/logs/result_${i}.log 2>&1
done


