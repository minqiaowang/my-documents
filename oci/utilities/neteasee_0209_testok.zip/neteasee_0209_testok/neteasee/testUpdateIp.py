#!/usr/bin/python3
 
import os
import sys
import shutil
import requests, json
import datetime, time
import configparser
import warnings
warnings.filterwarnings(action='ignore',message='Python 3.6 is no longer supported')
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    import oci
import platform
import getopt

_FILENAME=__file__

global _INST_OCID
#_INST_OCID
_INST_OCID=''
global _INST_NAME
_INST_NAME=''

usages = '''
Usage: %s [OPTION]
Test and Update the instacne IP address.
  -o   Instance OCID  The Instance OCID.
  -h/H Help
  example: %s -o ocid1.instance.oc1.ap-seoul-1.anuwgljrak7gbric4lwafquwucbrhxgsqdilcx5c7dichnyb7jzmbpzmt3nq
''' %(_FILENAME,_FILENAME)

global bUnreach #for test purpose
bUnreach=2

def getParameters():
    global _INST_OCID
    global _INST_NAME
    global _CONFIG_FILE
    try:
        opts, args = getopt.getopt(sys.argv[1:], '-H-h:-o:-i:')
        #print(opts)
        for opt_name, opt_value in opts:
            if opt_name in ('-H'):
                print(usages)
                sys.exit(1)
            if opt_name in ('-h'):
                print(usages)
                sys.exit(1)
            if opt_name in ('-o'):
                _INST_OCID = opt_value
                #print("_INST_OCID:"+_INST_OCID)
                continue;
            if opt_name in ('-i'):
                _INST_NAME = opt_value
                #print("_INST_NAME:"+_INST_NAME)
                continue;
    except getopt.GetoptError as e:
        print ('ERROR: %s' % str(e))
        print(usages)
        sys.exit(2)

class updateInstanceIpcls():
    def __init__(self):

        #use config file to do authticate, do not use DynamicGroup authenticate
        config = oci.config.from_file()
        self.core_client = oci.core.ComputeClient(config)
        self.core_vnc = oci.core.VirtualNetworkClient(config)     
        
    # delete public ip of instance
    def deletePublicIP(self,ipocid):
        pubip = ''
        try:
            if(len(ipocid) > 5 and ipocid != ''):
                #endpoint = '{0}/20160918/publicIps/{1}'.format(self.url,ipocid)
                #print(endpoint)
                #response = requests.delete(endpoint, json={}, auth=auth)
                #response.raise_for_status()
                #print('delete ' + pid)
                delete_public_ip_response = self.core_vnc.delete_public_ip(
                    public_ip_id=ipocid)
                #print(delete_public_ip_response.headers)
        except oci.exceptions.TransientServiceError as e:
            1 == 1
        except requests.exceptions.HTTPError as e:
            print(e.response.status_code)
            print(e.response.content)
        except oci.exceptions.ServiceError as e:
            1 == 1
        except:
            print('This private IP is not bind to public IP.')
        return pubip

    def createPublicIp(self,privocid, compartment_id, privlifetimes):
        #global compartmentId
        #print(f"createPublicIp:{privocid},{compartment_id},{privlifetimes}")
        publicip = ''
        try:
            create_public_ip_response = self.core_vnc.create_public_ip(
                create_public_ip_details=oci.core.models.CreatePublicIpDetails(
                    compartment_id=compartment_id,
                    lifetime=privlifetimes,        
                    private_ip_id=privocid))
            publicip = create_public_ip_response.data.ip_address
            print(f" Create a new Public IP:{publicip}")
            #print(create_public_ip_response.data)
            #publicip = newandbind(privocid)
            time.sleep(1)
        except oci.exceptions.ServiceError as e:
            time.sleep(3)
            create_public_ip_response = self.core_vnc.create_public_ip(
                create_public_ip_details=oci.core.models.CreatePublicIpDetails(
                    compartment_id=compartment_id,
                    lifetime=privlifetimes,
                    private_ip_id=privocid))
            publicip = create_public_ip_response.data.ip_address
        except requests.exceptions.HTTPError as e:
            time.sleep(3)
            create_public_ip_response = self.core_vnc.create_public_ip(
                           create_public_ip_details=oci.core.models.CreatePublicIpDetails(
                                   compartment_id=compartment_id,
                                   lifetime=privlifetimes,
                                   private_ip_id=privocid))
            #print(create_public_ip_response.data)
            publicip = create_public_ip_response.data.ip_address
        #print('{0} => {1}'.format(pid, publicip))
        return publicip
    # 
    # privarr= { privateIP: 'RESERVED' or compartmentid for EPHEMERAL ip}
    def test_DeletePublicIP(self,privocid,isPrimaryVnic,isPrimaryIp, privcompartmentid):

        #print("test_DeletePublicIP() entered.")
        single_privarr=''
        try:
            get_public_ip_response = self.core_vnc.get_public_ip_by_private_ip_id(
                get_public_ip_by_private_ip_id_details=oci.core.models.GetPublicIpByPrivateIpIdDetails(
                    private_ip_id=privocid))
            #print(get_public_ip_response.data)
            if( self.TestPing( get_public_ip_response.data.ip_address) == False):
                print('deletePublicIP 1=>'+privocid)			
                single_privarr=get_public_ip_response.data.lifetime
                self.deletePublicIP(get_public_ip_response.data.id)
            else:
                print(f"PublicIP {get_public_ip_response.data.ip_address} is reachable, keep it.")

        except Exception as e:
            print(e)

        return single_privarr

    # list ips of specified instance
    def listIpsofVnic(self,vnicid, subnetid, compartmentId):
        # get vnic info
        #print(f"listIpsofVnic(): vnicid={vnicid}")
        get_vnic_response = self.core_vnc.get_vnic(vnic_id=vnicid)
        isPrimaryVnic = get_vnic_response.data.is_primary
        #print(get_vnic_response.data.is_primary)
        
        list_private_ips_response = self.core_vnc.list_private_ips(
            subnet_id = subnetid,
            vnic_id = vnicid
            )
        #print(list_private_ips_response.data)
        for privip in list_private_ips_response.data:
            #print(f"privip:{privip}")
            time.sleep(1)
            if not privip.is_primary:
                while True:
                    privarr= self.test_DeletePublicIP(privip.id,isPrimaryVnic,privip.is_primary,privip.compartment_id)
                    if( privarr != ''):
                        time.sleep(1)
                        pubip = self.createPublicIp(privip.id, compartmentId, privarr)
                        tmpstmp=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        print(tmpstmp + ' new public ip => ' + pubip)
                        time.sleep(5) #sleep some time to wait the new IP can reachable
                    else:
                        break
                  
            
    def updateInstanceIPinfo(self,ocid):
        get_instance_response = self.core_client.get_instance(
            instance_id=ocid)

        compartmentId = get_instance_response.data.compartment_id
        availability_domain = get_instance_response.data.availability_domain


        #list vnics
        list_vnic_attachments_response = self.core_client.list_vnic_attachments(
            compartment_id = compartmentId,
            availability_domain = availability_domain,
            instance_id = ocid
            )
        #print (f"list_vnic_attachments_response:{list_vnic_attachments_response.data}")
        for vnic in list_vnic_attachments_response.data:
            if( vnic.lifecycle_state != 'ATTACHED'): continue
            #print(vnic)
            self.listIpsofVnic(vnic.vnic_id, vnic.subnet_id, compartmentId)
            
    def TestPing(self, publicIP):
        '''
        #global bUnreach
        #print(f"TestPing:{bUnreach}")
        #for test purpose
        if( bUnreach > 0 ):
            bUnreach = bUnreach -1 
            return False
        '''

        response = os.system("ping -c 1 " + publicIP)
        #and then check the response...
        if response == 0:
            return True
        
        
        return False
        
                
if __name__ == '__main__':
    getParameters()
    #print(f" {_INST_NAME},{_INST_OCID}")
    if( _INST_NAME != ''):
        _DIRNAME=os.path.dirname(os.path.realpath(__file__))
        inst_ocid_file = "%s/%s.%s" %(_DIRNAME,_INST_NAME,"ocid")

        #get inst ocid
        with open(inst_ocid_file) as fh:
            lines = fh.readlines()
            _INST_OCID = lines[0].split('=')[1].strip()

    if( _INST_OCID == ''):
        print("Please input instance OCID.")
        print(usages)
        sys.exit(2)   
    
    inst = updateInstanceIpcls()
    inst.updateInstanceIPinfo(_INST_OCID)
