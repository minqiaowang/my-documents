pushd /home/ubuntu/kbot
/home/ubuntu/miniconda/envs/kbot/bin/python main.py --port 443
