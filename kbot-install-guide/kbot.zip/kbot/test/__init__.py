

import array
emebdding=[11,.2]
vector_data_64 = array.array('d', emebdding)
print(vector_data_64[1])
