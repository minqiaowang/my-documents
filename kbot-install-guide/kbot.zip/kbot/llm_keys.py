#######  LLM API Key(Please replace the key with your own) #################
cohere_api_key='xx'
openai_key='sk-xx'
zhipu_api_key='xx.8we0mI6bLskbmmPT'
qwen_api_key='sk-xxx'

######  讯飞星火模型key配置开始 ######
xinghuo_appid="a4871479"
xinghuo_api_secret='xx'
xinghuo_api_key='xx'
#用于配置大模型版本，默认“general/generalv2”
xinghuo_domain = "generalv3"
#云端环境的服务地址
xinghuo_spark_url = "ws://spark-api.xf-yun.com/v3.1/chat"
######  讯飞星火模型key配置结束 ######
