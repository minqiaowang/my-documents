-- Drop the TPC-E schema owner

DROP USER &username CASCADE;

-- End
