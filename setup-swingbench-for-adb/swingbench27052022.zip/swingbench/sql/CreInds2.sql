alter			index
	pc_PK
rebuild partition
	&pc
/

