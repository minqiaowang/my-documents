drop user &username cascade;

drop tablespace &tablespace including contents and datafiles;


-- End;

