drop table SALES_1995 purge;

drop table SALES_1996 purge;

drop table SALES_Q1_2013 purge;

drop table SALES_Q2_2013 purge;

drop table SALES_Q3_2013 purge;

drop table SALES_Q4_2013 purge;

drop table SALES_Q4_2012 purge;

drop table SALES_Q3_2012 purge;

drop table SALES_Q2_2012 purge;

drop table SALES_Q4_2011 purge;

drop table SALES_Q3_2011 purge;

drop table SALES_Q2_2011 purge;

drop table SALES_Q4_2010 purge;

drop table SALES_Q4_2009 purge;

drop table SALES_Q4_2008 purge;

drop table SALES_Q4_2007 purge;

drop table SALES_Q4_2006 purge;

drop table SALES_Q4_2005 purge;

drop table SALES_Q4_2004 purge;

drop table SALES_Q4_2003 purge;

drop table SALES_Q4_2002 purge;

drop table SALES_Q4_2001 purge;

drop table SALES_Q4_1999 purge;

drop table SALES_Q4_1998 purge;

drop table SALES_Q3_2010 purge;

drop table SALES_Q3_2009 purge;

drop table SALES_Q3_2008 purge;

drop table SALES_Q3_2007 purge;

drop table SALES_Q3_2006 purge;

drop table SALES_Q3_2005 purge;

drop table SALES_Q3_2004 purge;

drop table SALES_Q3_2003 purge;

drop table SALES_Q3_2002 purge;

drop table SALES_Q3_2001 purge;

drop table SALES_Q3_1999 purge;

drop table SALES_Q3_1998 purge;

drop table SALES_Q2_2010 purge;

drop table SALES_Q2_2009 purge;

drop table SALES_Q2_2008 purge;

drop table SALES_Q2_2007 purge;

drop table SALES_Q2_2006 purge;

drop table SALES_Q2_2005 purge;

drop table SALES_Q2_2004 purge;

drop table SALES_Q2_2003 purge;

drop table SALES_Q2_2002 purge;

drop table SALES_Q2_2001 purge;

drop table SALES_Q2_1999 purge;

drop table SALES_Q2_1998 purge;

drop table SALES_Q1_2012 purge;

drop table SALES_Q1_2011 purge;

drop table SALES_Q1_2010 purge;

drop table SALES_Q1_2009 purge;

drop table SALES_Q1_2008 purge;

drop table SALES_Q1_2007 purge;

drop table SALES_Q1_2006 purge;

drop table SALES_Q1_2005 purge;

drop table SALES_Q1_2004 purge;

drop table SALES_Q1_2003 purge;

drop table SALES_Q1_2002 purge;

drop table SALES_Q1_2001 purge;

drop table SALES_Q1_1999 purge;

drop table SALES_Q1_1998 purge;

drop table SALES_H2_1997 purge;

drop table SALES_H1_1997 purge;

drop table SALES_Q4_2000 purge;

drop table SALES_Q3_2000 purge;

drop table SALES_Q2_2000 purge;

drop table SALES_Q1_2000 purge;

drop table CUSTOMERS1 purge;

drop table CUSTOMERS2 purge;

drop table CUSTOMERS3 purge;

drop table CUSTOMERS4 purge;

drop table CUSTOMERS5 purge;

drop table CUSTOMERS6 purge;

drop table CUSTOMERS7 purge;

drop table CUSTOMERS8 purge;

drop table CUSTOMERS9 purge;

drop table CUSTOMERS10 purge;

drop table CUSTOMERS11 purge;

drop table CUSTOMERS12 purge;

drop table CUSTOMERS13 purge;

drop table CUSTOMERS14 purge;

drop table CUSTOMERS15 purge;

drop table CUSTOMERS16 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS1 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS2 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS3 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS4 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS5 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS6 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS7 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS8 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS9 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS10 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS11 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS12 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS13 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS14 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS15 purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS16 purge;


-- End;


