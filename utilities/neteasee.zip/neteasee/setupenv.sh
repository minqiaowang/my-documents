sudo pip3 install --upgrade pip
sudo pip3 install configparser
sudo pip3 install httpsig_cffi
sudo pip3 install requests
sudo pip3 install oci
sudo pip3 install --upgrade oci
sudo pip3 install paramiko
sudo pip3 install cryptography
#sudo pip3 install --upgrade cryptography
