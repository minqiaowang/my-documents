#!/bin/bash
python3 setupInstance.py
python3 cfgInstance.py
